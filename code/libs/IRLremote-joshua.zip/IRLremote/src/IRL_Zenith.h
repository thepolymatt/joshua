/*
Copyright (c) 2014-2018 NicoHood
Adapted for Zenith protocol based on raw dump by [Your Name]

Revised Zenith UEI Protocol:
  Based on dump data, the remote produces pulses roughly as follows:
    – First pair (leader): mark ~500 µs, space ~520 µs.
    – Second pair (leader continuation): mark ~500 µs, space ~4120 µs.
    – Data bits:
         Logical 0: mark ~500 µs, space ~500 µs (total ~1000 µs).
         Logical 1: mark ~500 µs, space ~4100 µs (total ~4600 µs).
    – Total captured pulses: 33 (i.e. 16 full data bits, with the final mark).
  
Key updates:
  • Base pulse changed to 500 µs.
  • Leader thresholds adjusted so that a ~520 µs gap is treated as normal.
  • Logical threshold (limitLogic) set to 2000 µs.
  • Expected IR length (irLength) is defined as 33 so that available() returns true
    after receiving 17 pulses (the dump reported “17 bits … received”).
  
All parameters that mirror the Panasonic file (PANASONIC_*) now have a corresponding ZENITH_*
macro or function. When a protocol feature isn’t defined (e.g. checksum), a dummy implementation is used.
*/

#pragma once

#include "IRL_Receive.h"
#include "IRL_Time.h"
#include "IRL_Protocol.h"
#include "IRL_Decode.h"

//==============================================================================
// Zenith Protocol Definitions
//==============================================================================

// Base IR parameters – adjusted from raw dump
#define ZENITH_HZ                40000
#define ZENITH_PULSE             500UL    // Base unit: 500 µs

// Data format:  
// In our new analysis, the payload is 16 bits (8-bit device code + 8-bit command)
// Notice that IRLremote’s raw dump reported 17 bits (including the lead gap)
// so we set the total expected pulse count (irLength) to 33.
// (Because bits are represented by a mark and a space, normally one would expect 2 pulses per bit.
//  The first 2 pulses are taken by the leader, then 16*2 = 32 pulses; here we expect 33 entries.)
#define ZENITH_ADDRESS_LENGTH    8
#define ZENITH_COMMAND_LENGTH    8
#define ZENITH_DATA_LENGTH       (ZENITH_ADDRESS_LENGTH + ZENITH_COMMAND_LENGTH)  // 16 bits
#define ZENITH_BLOCKS            (ZENITH_DATA_LENGTH / 8)   // 2 blocks
#define ZENITH_LENGTH            33   // Adjusted to match raw dump

//------------------------------------------------------------------------------
// Lead-in Timing (using double-start style, as observed)
//------------------------------------------------------------------------------
#define ZENITH_LEAD1_MARK        (ZENITH_PULSE)                      // ~500 µs
#define ZENITH_LEAD1_SPACE       (ZENITH_PULSE)                      // ~500 µs
#define ZENITH_LEAD2_MARK        (ZENITH_PULSE)                      // ~500 µs
#define ZENITH_LEAD2_SPACE       (ZENITH_PULSE * 8UL + 100UL)          // 500*8 + 100 = 4100 µs (adjusted)
#define ZENITH_LOGICAL_LEAD      (ZENITH_LEAD1_MARK + ZENITH_LEAD1_SPACE + ZENITH_LEAD2_MARK + ZENITH_LEAD2_SPACE)  // ~5600 µs

//------------------------------------------------------------------------------
// Data Bit Timings
//------------------------------------------------------------------------------
#define ZENITH_MARK_ZERO         (ZENITH_PULSE)          // ~500 µs
#define ZENITH_SPACE_ZERO        (ZENITH_PULSE)          // ~500 µs
#define ZENITH_LOGICAL_ZERO      (ZENITH_MARK_ZERO + ZENITH_SPACE_ZERO)  // 1000 µs

#define ZENITH_MARK_ONE          (ZENITH_PULSE)          // ~500 µs
#define ZENITH_SPACE_ONE         (ZENITH_PULSE * 8UL + 100UL)  // 4100 µs (adjusted)
#define ZENITH_LOGICAL_ONE       (ZENITH_MARK_ONE + ZENITH_SPACE_ONE)       // 4600 µs

//------------------------------------------------------------------------------
// Timeouts and Logical Thresholds
//------------------------------------------------------------------------------
#define ZENITH_TIMEOUT           (60000UL)       // Allow full frame (≈56 ms) with margin
#define ZENITH_LIMIT_LOGIC       (2000UL)        // Threshold between 0 (~500) and 1 (~4100)
#define ZENITH_LIMIT_HOLDING     (300UL)         // Minimum valid leader gap; below this, error out
#define ZENITH_LIMIT_LEAD        (500UL)         // If the gap is below 500 µs, treat as a repeat signal (holding)

// For repeat detection (not used if no repeat is needed)
// Calculation based on a sum: timeout + leader duration + (half the bits * each bit duration)
// (This value may be adjusted as needed.)
#define ZENITH_TIMESPAN_HOLDING  (ZENITH_TIMEOUT + ZENITH_LOGICAL_LEAD + (((ZENITH_DATA_LENGTH) / 2) * ZENITH_LOGICAL_ONE) + (((ZENITH_DATA_LENGTH) / 2) * ZENITH_LOGICAL_ZERO))
#define ZENITH_LIMIT_REPEAT      (ZENITH_TIMESPAN_HOLDING * 3UL / 2UL)


//==============================================================================
// Zenith Data Structures
//==============================================================================
//
// This union holds the decoded 16-bit payload: 8 bits for device (address) and 8 bits for command.
typedef uint8_t Zenith_address_t;
typedef uint8_t Zenith_command_t;

union Zenith_data_t
{
    struct {
        Zenith_address_t address;  // 8-bit device code
        Zenith_command_t command;  // 8-bit command/extra data
    };
    struct {
        uint8_t device; // Original button code (device)
        uint8_t misc;   // Extra (if applicable)
    } decoded;
};


//==============================================================================
// Zenith Decoding Class
//==============================================================================
//
// Mirrors the Panasonic class. All timing and protocol interface functions
// are provided so that IRLremote’s interrupt-driven routine will collect pulses,
// shift in data bits, and eventually signal that a complete frame is available.
class CZenith : public CIRL_Receive<CZenith>,
                public CIRL_Time<CZenith>,
                public CIRL_Protocol<CZenith, Zenith_data_t>,
                public CIRL_DecodeSpaces<CZenith, ZENITH_BLOCKS>
{
protected:
    // Use the parameters defined above.
    static constexpr uint32_t timespanEvent = ZENITH_TIMESPAN_HOLDING;
    static constexpr uint32_t limitTimeout  = ZENITH_TIMEOUT;
    static constexpr uint32_t limitLead     = ZENITH_LIMIT_LEAD;
    static constexpr uint32_t limitHolding  = ZENITH_LIMIT_HOLDING;
    static constexpr uint32_t limitLogic    = ZENITH_LIMIT_LOGIC;
    static constexpr uint32_t limitRepeat   = ZENITH_LIMIT_REPEAT;
    static constexpr uint8_t  irLength      = ZENITH_LENGTH;

    friend CIRL_Receive<CZenith>;
    friend CIRL_Protocol<CZenith, Zenith_data_t>;
    friend CIRL_DecodeSpaces<CZenith, ZENITH_BLOCKS>;

    // Protocol interface functions used by IRLremote’s decode routine
    inline Zenith_data_t getData(void);
    static inline bool checksum(void);
    static inline void holding(void);
};


//==============================================================================
// Zenith Decoding Implementation
//==============================================================================
//
// The interrupt-driven routine in CIRL_DecodeSpaces will call getData() once
// enough pulses have been collected (i.e. when count > (irLength/2)). In our case,
// with irLength set to 33, that is when count ≥ 17. The getData() routine simply
// assembles the two bytes (8 bits each) that were built, in order, during the ISR.
inline Zenith_data_t CZenith::getData(void) {
    Zenith_data_t retdata;
    // The first byte holds the device (address) and the second holds the command/misc.
    retdata.address = data[0];  // First 8 bits built from the interrupts
    retdata.command = data[1];  // Next 8 bits of the payload
    return retdata;
}

// The checksum is not defined for Zenith – assume true.
inline bool CZenith::checksum(void) {
    return true;
}

// No holding functionality is defined; dummy implementation.
inline void CZenith::holding(void) {
    return;
}